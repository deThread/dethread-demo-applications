import React, { Component } from 'react';

class Motivation extends Component {
  render(){
    return (<div>
              <div className="section2">
                <h2> Why we do what we do- </h2>
                <div className="textContainer">
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sagittis, nunc at varius sagittis, ligula est suscipit odio, sed cursus lectus nunc vel nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse a ligula hendrerit, consequat nisi sit amet, pretium neque. Ut vehicula ac lorem id feugiat. Nunc massa lectus, consequat at augue sit amet, pellentesque vulputate justo. Sed finibus eros ante. Ut at tellus id dolor commodo dapibus id vitae massa. Mauris ac pulvinar enim, eu cursus est. Phasellus in mi sed sem elementum vulputate.</p>
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sagittis, nunc at varius sagittis, ligula est suscipit odio, sed cursus lectus nunc vel nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse a ligula hendrerit, consequat nisi sit amet, pretium neque. Ut vehicula ac lorem id feugiat. Nunc massa lectus, consequat at augue sit amet, pellentesque vulputate justo. Sed finibus eros ante. Ut at tellus id dolor commodo dapibus id vitae massa. Mauris ac pulvinar enim, eu cursus est. Phasellus in mi sed sem elementum vulputate.</p>
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sagittis, nunc at varius sagittis, ligula est suscipit odio, sed cursus lectus nunc vel nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse a ligula hendrerit, consequat nisi sit amet, pretium neque. Ut vehicula ac lorem id feugiat. Nunc massa lectus, consequat at augue sit amet, pellentesque vulputate justo. Sed finibus eros ante. Ut at tellus id dolor commodo dapibus id vitae massa. Mauris ac pulvinar enim, eu cursus est. Phasellus in mi sed sem elementum vulputate.</p>
                </div>
              </div>
            </div>
            
          )
  }
}

export default Motivation;