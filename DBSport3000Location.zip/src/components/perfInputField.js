// import React, { Component } from 'react';

// class inputField extends Component{
// constructor(props){
//   super(props);
//   this.state = {length: null, hash : null, workers : null}
// }
// render(){

// }
// }

// export default inputField;