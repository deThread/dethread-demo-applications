# Distributed-Computing-for-Teams
A platform for users to share CPU intensive problems across a distributed network of computers, built with JavaScript.
