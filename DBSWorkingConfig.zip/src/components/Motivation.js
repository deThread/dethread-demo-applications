import React, { Component } from 'react';

class Motivation extends Component {
  render(){
    return (<div>
              <div className="section2">
                <h2> What motivates us? </h2>
                <div className="textContainer">
                  <article>
                    <p>The possibility of utilizing millions of idle computers to do something great.</p>
                  </article>
                </div>
              </div>
            </div>
            
          )
  }
}

export default Motivation;