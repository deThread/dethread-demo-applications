import React, { Component } from 'react';

const Connection = () => {
return (<div>
          <img className="connection" src="http://www.isdecisions.com/blog/wp-content/uploads/2015/06/check-users-logged-windows-server.png"/>
        </div>
)
}

export default Connection;