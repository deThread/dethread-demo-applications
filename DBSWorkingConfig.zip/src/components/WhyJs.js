import React, { Component } from 'react';

const WhyJS = () => {
return (<div>
          <div className="section section3">
            <h2> Why JavaScript? </h2>
            <article>
              <p>  Although lower level languages are generally considered more flexible or powerful solutions
              to this problem, implementing a solution with JavaScript ensures that any device with
              a web browser can participate </p>
            </article>
          </div>
        </div>
)
}

export default WhyJS;