import React, { Component } from 'react';

const Spinner = () => {
  return (<div>
            <div className="spinner">
					    <div className="any-element animation is_loading">
  				 	    &nbsp;
  				    </div>
            </div>
          </div>)
}

export default Spinner;