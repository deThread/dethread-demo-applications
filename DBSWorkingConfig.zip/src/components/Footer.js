import React, { Component } from 'react';

class Footer extends Component {
  render(){
    return (<div>
              <footer className="footer">
                <div className="container">
                  <span className="text-muted">Connect with us on Github-</span>
                </div>
              </footer>
            </div>
          )
  }
}

export default Footer;